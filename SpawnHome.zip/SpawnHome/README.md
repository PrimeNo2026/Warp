# SpawnHome

Paper-Plugin (Paper 26.3, Java 25): `/spawn`, Home-System, `/locatehome` und gestaltete Fluesternachrichten.

## Befehle
| Befehl | Beschreibung |
|---|---|
| `/spawn` | Teleport zum Spawn (Koordinaten in der Config) |
| `/sethome [Name]` | Home setzen (Standardname `home`), 3 pro Dimension |
| `/home [Name]` | Zum Home teleportieren |
| `/delhome <Name>` | Home loeschen |
| `/homes` | Alle Homes anzeigen (anklickbar) |
| `/locatehome [Name]` | Partikelspur zum Home (nur fuer dich sichtbar, 2 Minuten) |
| `/homeplugin on\|off\|reload` | Home-System ein-/ausschalten bzw. Config neu laden (Admin) |
| `/msg`, `/tell`, `/w` | Ausgabe als `[Absender -> Du] Text` mit wechselnden Farben |

## Regeln fuer /spawn und /home
- 15 Sekunden Countdown: still stehen, keinen Schaden erleiden, keine Bloecke platzieren/abbauen.
- Gesperrt, wenn man in den letzten 5 Minuten gegen einen Spieler gekaempft hat.
- Nach jedem Teleport 10 Minuten Cooldown (gemeinsam fuer /spawn und /home).
- Alle Zeiten, Koordinaten und Nachrichten stehen in `plugins/SpawnHome/config.yml`.

## Berechtigungen
- `spawnhome.spawn`, `spawnhome.home`: Standard fuer alle
- `spawnhome.admin`: nur OPs (`/homeplugin`)
- `spawnhome.bypass`: ignoriert Countdown, Cooldown und Kampfsperre (Standard: niemand)

## Bauen
`mvn package` (Java 25). Die fertige JAR liegt in `target/`.
