package de.spawnhome;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Liest alle Einstellungen aus der config.yml (mit Validierung). */
public final class Settings {

    private static final Pattern STYLE = Pattern.compile("[a-z_]+(:[#A-Za-z0-9_.\\-]+)*");
    private static final List<String> DEFAULT_STYLES = List.of(
            "gradient:#ff512f:#dd2476",
            "gradient:#00c6ff:#0072ff",
            "gradient:#43e97b:#38f9d7",
            "gradient:#f7971e:#ffd200",
            "gradient:#a18cd1:#fbc2eb",
            "rainbow");

    private final SpawnHomePlugin plugin;

    private String spawnWorld;
    private double spawnX;
    private double spawnY;
    private double spawnZ;
    private float spawnYaw;
    private float spawnPitch;
    private int countdownSeconds;
    private int cooldownSeconds;
    private int combatBlockSeconds;
    private int maxHomesPerDimension;
    private String defaultHomeName;
    private int locateDurationSeconds;
    private double locateArriveDistance;
    private boolean whisperEnabled;
    private String youLabel;
    private List<String> whisperStyles;

    public Settings(SpawnHomePlugin plugin) {
        this.plugin = plugin;
        load();
    }

    /** Laedt die config.yml von der Festplatte neu. */
    public void reload() {
        plugin.reloadConfig();
        load();
    }

    private void load() {
        FileConfiguration c = plugin.getConfig();

        spawnWorld = c.getString("spawn.world", "world");
        spawnX = c.getDouble("spawn.x", 0.5);
        spawnY = c.getDouble("spawn.y", 100.0);
        spawnZ = c.getDouble("spawn.z", 0.5);
        spawnYaw = (float) c.getDouble("spawn.yaw", 0.0);
        spawnPitch = (float) c.getDouble("spawn.pitch", 0.0);

        countdownSeconds = Math.max(0, c.getInt("teleport.countdown-seconds", 15));
        cooldownSeconds = Math.max(0, c.getInt("teleport.cooldown-seconds", 600));
        combatBlockSeconds = Math.max(0, c.getInt("teleport.combat-block-seconds", 300));

        maxHomesPerDimension = Math.max(1, c.getInt("homes.max-per-dimension", 3));
        String name = c.getString("homes.default-name", "home");
        defaultHomeName = HomeManager.isValidName(name) ? name : "home";
        locateDurationSeconds = Math.max(1, c.getInt("homes.locate-duration-seconds", 120));
        locateArriveDistance = Math.max(0.5, c.getDouble("homes.locate-arrive-distance", 2.5));

        whisperEnabled = c.getBoolean("whisper.enabled", true);
        String label = c.getString("whisper.you-label", "Du");
        youLabel = (label == null || label.isBlank()) ? "Du" : label;

        List<String> styles = new ArrayList<>();
        for (String style : c.getStringList("whisper.styles")) {
            if (style != null && STYLE.matcher(style).matches()) {
                styles.add(style);
            } else {
                plugin.getLogger().warning("Ungueltiger Whisper-Stil in der Config ignoriert: " + style);
            }
        }
        whisperStyles = styles.isEmpty() ? DEFAULT_STYLES : List.copyOf(styles);
    }

    /** @return die Spawn-Position oder {@code null}, wenn die Welt nicht existiert. */
    public Location spawnLocation() {
        World world;
        if (spawnWorld == null || spawnWorld.isBlank()) {
            List<World> worlds = Bukkit.getWorlds();
            world = worlds.isEmpty() ? null : worlds.get(0);
        } else {
            world = Bukkit.getWorld(spawnWorld);
        }
        if (world == null) {
            return null;
        }
        return new Location(world, spawnX, spawnY, spawnZ, spawnYaw, spawnPitch);
    }

    public String dimensionName(String environment) {
        FileConfiguration c = plugin.getConfig();
        String direct = c.getString("dimensions." + environment);
        if (direct != null) {
            return direct;
        }
        return c.getString("dimensions.CUSTOM", environment);
    }

    public int countdownSeconds() { return countdownSeconds; }
    public int cooldownSeconds() { return cooldownSeconds; }
    public int combatBlockSeconds() { return combatBlockSeconds; }
    public int maxHomesPerDimension() { return maxHomesPerDimension; }
    public String defaultHomeName() { return defaultHomeName; }
    public int locateDurationSeconds() { return locateDurationSeconds; }
    public double locateArriveDistance() { return locateArriveDistance; }
    public boolean whisperEnabled() { return whisperEnabled; }
    public String youLabel() { return youLabel; }
    public List<String> whisperStyles() { return whisperStyles; }
}
