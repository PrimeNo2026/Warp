package de.spawnhome;

import de.spawnhome.HomeManager.Home;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;

import static de.spawnhome.Messages.ph;

/**
 * Zentrale Teleport-Logik fuer /spawn und /home:
 * Countdown, Abbruchbedingungen, Cooldown und Kampfsperre.
 */
public final class TeleportManager {

    public enum Kind { SPAWN, HOME }

    /** Erlaubte Abweichung (quadriert, in Bloecken) vom Startpunkt, bevor der Countdown abbricht. */
    private static final double MOVE_TOLERANCE_SQUARED = 0.0625;
    private static final String BYPASS_PERMISSION = "spawnhome.bypass";

    private static final class Session {
        final UUID uuid;
        final Kind kind;
        final String homeKey;
        final String displayName;
        final Location start;
        int remaining;
        BukkitTask task;
        boolean finishing;

        Session(UUID uuid, Kind kind, String homeKey, String displayName, Location start) {
            this.uuid = uuid;
            this.kind = kind;
            this.homeKey = homeKey;
            this.displayName = displayName;
            this.start = start;
        }
    }

    private record Resolved(Location location, String errorKey) { }

    private final SpawnHomePlugin plugin;
    private final Settings settings;
    private final Messages messages;
    private final HomeManager homes;

    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, Long> cooldownUntil = new HashMap<>();
    private final Map<UUID, Long> lastCombat = new HashMap<>();

    public TeleportManager(SpawnHomePlugin plugin, Settings settings, Messages messages, HomeManager homes) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.homes = homes;
    }

    // ------------------------------------------------------------------ Start

    /**
     * Startet einen Teleport mit Countdown.
     *
     * @param homeKey     Schluessel des Homes (nur bei {@link Kind#HOME})
     * @param displayName Anzeigename fuer Nachrichten (leer bei Spawn)
     */
    public void start(Player player, Kind kind, String homeKey, String displayName) {
        UUID id = player.getUniqueId();
        if (sessions.containsKey(id)) {
            messages.send(player, "already-teleporting");
            return;
        }

        boolean bypass = player.hasPermission(BYPASS_PERMISSION);
        if (!bypass) {
            long combat = combatRemainingSeconds(id);
            if (combat > 0) {
                messages.send(player, "combat-block", ph("time", Messages.duration(combat)));
                return;
            }
            long cooldown = cooldownRemainingSeconds(id);
            if (cooldown > 0) {
                messages.send(player, "cooldown", ph("time", Messages.duration(cooldown)));
                return;
            }
        }

        Resolved resolved = resolve(id, kind, homeKey);
        if (resolved.location() == null) {
            messages.send(player, resolved.errorKey(), ph("name", displayName));
            return;
        }

        Session session = new Session(id, kind, homeKey, displayName, player.getLocation().clone());
        sessions.put(id, session);

        int delay = bypass ? 0 : settings.countdownSeconds();
        if (delay <= 0) {
            finish(session);
            return;
        }
        session.remaining = delay;
        messages.send(player, "countdown-start", ph("seconds", delay));
        session.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(session), 0L, 20L);
    }

    // -------------------------------------------------------------- Countdown

    private void tick(Session session) {
        Player player = Bukkit.getPlayer(session.uuid);
        if (player == null || sessions.get(session.uuid) != session) {
            discard(session);
            return;
        }
        if (session.finishing) {
            return;
        }
        if (session.remaining <= 0) {
            finish(session);
            return;
        }
        player.sendActionBar(messages.plain("actionbar-countdown", ph("seconds", session.remaining)));
        session.remaining--;
    }

    private void finish(Session session) {
        session.finishing = true;
        if (session.task != null) {
            session.task.cancel();
        }
        Player player = Bukkit.getPlayer(session.uuid);
        if (player == null) {
            sessions.remove(session.uuid, session);
            return;
        }
        Resolved resolved = resolve(session.uuid, session.kind, session.homeKey);
        if (resolved.location() == null) {
            sessions.remove(session.uuid, session);
            player.sendActionBar(Component.empty());
            messages.send(player, resolved.errorKey(), ph("name", session.displayName));
            return;
        }
        Location destination = resolved.location();
        World world = destination.getWorld();
        // Zielchunk asynchron laden, damit der Teleport den Server nicht blockiert.
        world.getChunkAtAsync(destination).whenComplete((chunk, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> complete(session, destination, error)));
    }

    private void complete(Session session, Location destination, Throwable error) {
        if (sessions.get(session.uuid) != session) {
            return; // Spieler hat den Server verlassen oder das Plugin wurde gestoppt
        }
        sessions.remove(session.uuid);
        Player player = Bukkit.getPlayer(session.uuid);
        if (player == null || player.isDead()) {
            return;
        }
        player.sendActionBar(Component.empty());

        if (error != null) {
            plugin.getLogger().log(Level.WARNING, "Zielchunk konnte nicht geladen werden.", error);
            messages.send(player, "teleport-failed");
            return;
        }
        if (session.kind == Kind.HOME && !homes.isEnabled()) {
            messages.send(player, "cancel-disabled");
            return;
        }
        if (isBlocked(destination)) {
            messages.send(player, "teleport-blocked");
            return;
        }
        if (player.isInsideVehicle()) {
            player.leaveVehicle();
        }
        if (!player.teleport(destination)) {
            messages.send(player, "teleport-failed");
            return;
        }

        if (!player.hasPermission(BYPASS_PERMISSION) && settings.cooldownSeconds() > 0) {
            cooldownUntil.put(session.uuid, System.currentTimeMillis() + settings.cooldownSeconds() * 1000L);
        }
        if (session.kind == Kind.SPAWN) {
            messages.send(player, "teleported-spawn");
        } else {
            messages.send(player, "teleported-home", ph("name", session.displayName));
        }
    }

    private Resolved resolve(UUID uuid, Kind kind, String homeKey) {
        if (kind == Kind.SPAWN) {
            Location spawn = settings.spawnLocation();
            return spawn == null ? new Resolved(null, "spawn-world-missing") : new Resolved(spawn, null);
        }
        if (!homes.isEnabled()) {
            return new Resolved(null, "home-disabled");
        }
        Optional<Home> home = homes.get(uuid, homeKey);
        if (home.isEmpty()) {
            return new Resolved(null, "home-gone");
        }
        Location location = home.get().toLocation();
        return location == null ? new Resolved(null, "home-world-missing") : new Resolved(location, null);
    }

    /** Verhindert Ersticken: Fuss- oder Augenblock ist ein vollstaendig undurchsichtiger Block. */
    private static boolean isBlocked(Location location) {
        Block feet = location.getBlock();
        Block eyes = location.clone().add(0, 1.62, 0).getBlock();
        return feet.getType().isOccluding() || eyes.getType().isOccluding();
    }

    // ------------------------------------------------------------- Abbrechen

    public boolean hasSessions() {
        return !sessions.isEmpty();
    }

    /** Bricht einen laufenden Countdown mit einer Begruendung ab (laufende Teleports werden nicht gestoert). */
    public void cancel(UUID id, String reasonKey) {
        Session session = sessions.get(id);
        if (session == null || session.finishing) {
            return;
        }
        discard(session);
        Player player = Bukkit.getPlayer(id);
        if (player != null && player.isOnline()) {
            player.sendActionBar(Component.empty());
            messages.send(player, reasonKey);
        }
    }

    /** Entfernt eine Session ohne Nachricht (z. B. beim Verlassen des Servers). */
    public void remove(UUID id) {
        Session session = sessions.remove(id);
        if (session != null && session.task != null) {
            session.task.cancel();
        }
    }

    public void cancelHomeSessions() {
        for (Session session : new ArrayList<>(sessions.values())) {
            if (session.kind == Kind.HOME) {
                cancel(session.uuid, "cancel-disabled");
            }
        }
    }

    public void cancelAll() {
        for (Session session : sessions.values()) {
            if (session.task != null) {
                session.task.cancel();
            }
        }
        sessions.clear();
    }

    /** Bricht ab, wenn sich der Spieler zu weit vom Startpunkt entfernt hat (Kopfdrehung ist erlaubt). */
    public void checkMove(Player player, Location to) {
        Session session = sessions.get(player.getUniqueId());
        if (session == null || session.finishing) {
            return;
        }
        if (!Objects.equals(session.start.getWorld(), to.getWorld())
                || session.start.distanceSquared(to) > MOVE_TOLERANCE_SQUARED) {
            cancel(player.getUniqueId(), "cancel-move");
        }
    }

    private void discard(Session session) {
        sessions.remove(session.uuid, session);
        if (session.task != null) {
            session.task.cancel();
        }
    }

    // ------------------------------------------------- Cooldown / Kampfsperre

    public void markCombat(UUID a, UUID b) {
        if (settings.combatBlockSeconds() <= 0) {
            return;
        }
        long now = System.currentTimeMillis();
        lastCombat.put(a, now);
        lastCombat.put(b, now);
    }

    private long combatRemainingSeconds(UUID id) {
        Long last = lastCombat.get(id);
        if (last == null) {
            return 0;
        }
        long remainingMillis = last + settings.combatBlockSeconds() * 1000L - System.currentTimeMillis();
        if (remainingMillis <= 0) {
            lastCombat.remove(id);
            return 0;
        }
        return (remainingMillis + 999) / 1000;
    }

    private long cooldownRemainingSeconds(UUID id) {
        Long until = cooldownUntil.get(id);
        if (until == null) {
            return 0;
        }
        long remainingMillis = until - System.currentTimeMillis();
        if (remainingMillis <= 0) {
            cooldownUntil.remove(id);
            return 0;
        }
        return (remainingMillis + 999) / 1000;
    }
}
