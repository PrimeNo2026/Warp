package de.spawnhome;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Ersetzt die Vanilla-Ausgabe von /msg, /tell und /w durch "[Absender -> Empfaenger] Text".
 * Der Klammerteil bekommt pro Nachricht einen zufaelligen Farbstil (Farbverlauf/Regenbogen),
 * Sender und Empfaenger sehen denselben Stil.
 * Ist die Anfrage ungueltig (Ziel nicht gefunden, kein Text), bleibt die Vanilla-Fehlermeldung bestehen.
 */
public final class WhisperListener implements Listener {

    private static final Set<String> LABELS = Set.of("msg", "tell", "w");
    private static final String VANILLA_PREFIX = "minecraft:";
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Settings settings;

    public WhisperListener(Settings settings) {
        this.settings = settings;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!settings.whisperEnabled()) {
            return;
        }
        String raw = event.getMessage();
        if (raw.length() < 2 || raw.charAt(0) != '/') {
            return;
        }
        String body = raw.substring(1);
        int firstSpace = body.indexOf(' ');
        if (firstSpace < 0) {
            return;
        }
        String label = body.substring(0, firstSpace).toLowerCase(Locale.ROOT);
        if (label.startsWith(VANILLA_PREFIX)) {
            label = label.substring(VANILLA_PREFIX.length());
        }
        if (!LABELS.contains(label)) {
            return;
        }

        String rest = body.substring(firstSpace + 1).stripLeading();
        int secondSpace = rest.indexOf(' ');
        if (secondSpace < 0) {
            return;
        }
        String targetArgument = rest.substring(0, secondSpace);
        String text = rest.substring(secondSpace + 1).strip();
        if (text.isEmpty()) {
            return;
        }

        Player sender = event.getPlayer();
        List<Player> targets = findTargets(sender, targetArgument);
        if (targets.isEmpty()) {
            return; // Vanilla meldet den Fehler selbst
        }
        event.setCancelled(true);

        String style = settings.whisperStyles()
                .get(ThreadLocalRandom.current().nextInt(settings.whisperStyles().size()));
        String you = settings.youLabel();
        for (Player target : new LinkedHashSet<>(targets)) {
            target.sendMessage(format(style, sender.getName(), you, text));
            sender.sendMessage(format(style, you, target.getName(), text));
        }
    }

    private static List<Player> findTargets(Player sender, String argument) {
        List<Player> result = new ArrayList<>();
        if (argument.startsWith("@")) {
            try {
                for (Entity entity : Bukkit.selectEntities(sender, argument)) {
                    if (entity instanceof Player player) {
                        result.add(player);
                    }
                }
            } catch (IllegalArgumentException ignored) {
                // ungueltiger Selektor oder keine Berechtigung: Vanilla meldet den Fehler
            }
            return result;
        }
        Player player = Bukkit.getPlayerExact(argument);
        if (player != null) {
            result.add(player);
        }
        return result;
    }

    private static Component format(String style, String from, String to, String text) {
        int colon = style.indexOf(':');
        String tagName = colon < 0 ? style : style.substring(0, colon);
        try {
            return MM.deserialize(
                    "<" + style + ">[<from> -> <to>]</" + tagName + "> <white><text></white>",
                    Placeholder.unparsed("from", from),
                    Placeholder.unparsed("to", to),
                    Placeholder.unparsed("text", text));
        } catch (RuntimeException ex) {
            return Component.text("[" + from + " -> " + to + "] " + text);
        }
    }
}
