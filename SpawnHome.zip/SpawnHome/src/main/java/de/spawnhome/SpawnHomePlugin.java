package de.spawnhome;

import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.java.JavaPlugin;

/** SpawnHome: /spawn, Home-System, /locatehome und gestaltete Fluesternachrichten. */
public final class SpawnHomePlugin extends JavaPlugin {

    private HomeManager homes;
    private TeleportManager teleports;
    private LocateManager locates;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        Settings settings = new Settings(this);
        Messages messages = new Messages(this);
        homes = new HomeManager(this);
        homes.load();
        teleports = new TeleportManager(this, settings, messages, homes);
        locates = new LocateManager(this, settings, messages, homes);

        register("spawn", new SpawnCommand(messages, teleports));

        HomeCommands homeCommands = new HomeCommands(settings, messages, homes, teleports, locates);
        for (String name : new String[] {"home", "sethome", "delhome", "homes", "locatehome"}) {
            register(name, homeCommands);
        }
        register("homeplugin", new HomePluginCommand(settings, messages, homes, teleports, locates));

        getServer().getPluginManager().registerEvents(new TeleportListener(teleports, locates), this);
        getServer().getPluginManager().registerEvents(new WhisperListener(settings), this);

        getLogger().info("SpawnHome aktiviert (Home-System: " + (homes.isEnabled() ? "an" : "aus") + ").");
    }

    @Override
    public void onDisable() {
        if (locates != null) {
            locates.stopAll(null);
        }
        if (teleports != null) {
            teleports.cancelAll();
        }
        if (homes != null) {
            homes.save();
        }
    }

    private void register(String name, CommandExecutor executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Befehl fehlt in der plugin.yml: " + name);
            return;
        }
        command.setExecutor(executor);
        if (executor instanceof TabCompleter completer) {
            command.setTabCompleter(completer);
        }
    }
}
