package de.spawnhome;

import de.spawnhome.HomeManager.Home;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static de.spawnhome.Messages.ph;

/** Zeigt per /locatehome eine Partikelspur zum Home. Die Partikel sehen nur der ausfuehrende Spieler. */
public final class LocateManager {

    private static final long PERIOD_TICKS = 10L;
    private static final double TRAIL_LENGTH = 24.0;
    private static final double TRAIL_SPACING = 1.0;
    private static final double MARKER_RANGE = 48.0;
    private static final double HEIGHT_OFFSET = 0.6;

    private static final class Tracking {
        final String homeKey;
        final String displayName;
        final long endMillis;
        BukkitTask task;

        Tracking(String homeKey, String displayName, long endMillis) {
            this.homeKey = homeKey;
            this.displayName = displayName;
            this.endMillis = endMillis;
        }
    }

    private final SpawnHomePlugin plugin;
    private final Settings settings;
    private final Messages messages;
    private final HomeManager homes;
    private final Map<UUID, Tracking> active = new HashMap<>();

    public LocateManager(SpawnHomePlugin plugin, Settings settings, Messages messages, HomeManager homes) {
        this.plugin = plugin;
        this.settings = settings;
        this.messages = messages;
        this.homes = homes;
    }

    /** Startet die Spur (ersetzt eine bereits laufende). Das Home muss in der Welt des Spielers liegen. */
    public void start(Player player, Home home) {
        UUID id = player.getUniqueId();
        stop(id, null);

        Location target = home.toLocation();
        if (target == null || !target.getWorld().equals(player.getWorld())) {
            return;
        }
        long end = System.currentTimeMillis() + settings.locateDurationSeconds() * 1000L;
        Tracking tracking = new Tracking(HomeManager.key(home.name()), home.name(), end);
        active.put(id, tracking);

        double distance = player.getLocation().distance(target);
        messages.send(player, "locate-start",
                ph("name", home.name()),
                ph("distance", Math.round(distance)),
                ph("seconds", settings.locateDurationSeconds()));

        tracking.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(id), 0L, PERIOD_TICKS);
    }

    /** Beendet die Spur eines Spielers; {@code messageKey} darf {@code null} sein (keine Nachricht). */
    public void stop(UUID id, String messageKey, TagResolver... resolvers) {
        Tracking tracking = active.remove(id);
        if (tracking == null) {
            return;
        }
        if (tracking.task != null) {
            tracking.task.cancel();
        }
        if (messageKey != null) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                messages.send(player, messageKey, resolvers);
            }
        }
    }

    public void stopAll(String messageKey) {
        for (UUID id : new ArrayList<>(active.keySet())) {
            stop(id, messageKey);
        }
    }

    private void tick(UUID id) {
        Tracking tracking = active.get(id);
        if (tracking == null) {
            return;
        }
        Player player = Bukkit.getPlayer(id);
        if (player == null) {
            stop(id, null);
            return;
        }
        if (!homes.isEnabled()) {
            stop(id, "home-disabled");
            return;
        }
        Optional<Home> home = homes.get(id, tracking.homeKey);
        if (home.isEmpty()) {
            stop(id, "locate-gone");
            return;
        }
        Location target = home.get().toLocation();
        Location here = player.getLocation();
        if (target == null || !target.getWorld().equals(here.getWorld())) {
            stop(id, "locate-world");
            return;
        }
        if (System.currentTimeMillis() >= tracking.endMillis) {
            stop(id, "locate-timeout");
            return;
        }
        double distance = here.distance(target);
        if (distance <= settings.locateArriveDistance()) {
            stop(id, "locate-arrived", ph("name", home.get().name()));
            return;
        }
        draw(player, here, target);
    }

    private void draw(Player player, Location here, Location target) {
        double fromX = here.getX();
        double fromY = here.getY() + HEIGHT_OFFSET;
        double fromZ = here.getZ();
        double dx = target.getX() - fromX;
        double dy = target.getY() + HEIGHT_OFFSET - fromY;
        double dz = target.getZ() - fromZ;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (distance < 1.0E-6) {
            return;
        }
        double dirX = dx / distance;
        double dirY = dy / distance;
        double dirZ = dz / distance;

        double length = Math.min(distance, TRAIL_LENGTH);
        for (double d = 1.5; d <= length; d += TRAIL_SPACING) {
            player.spawnParticle(Particle.END_ROD,
                    fromX + dirX * d, fromY + dirY * d, fromZ + dirZ * d,
                    1, 0.0, 0.0, 0.0, 0.0);
        }
        if (distance <= MARKER_RANGE) {
            for (double up = 0.0; up <= 3.0; up += 0.5) {
                player.spawnParticle(Particle.END_ROD,
                        target.getX(), target.getY() + up, target.getZ(),
                        1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }
}
