package de.spawnhome;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;

/** Laedt Nachrichten aus der config.yml (MiniMessage) und sendet sie. */
public final class Messages {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final SpawnHomePlugin plugin;

    public Messages(SpawnHomePlugin plugin) {
        this.plugin = plugin;
    }

    private String raw(String key) {
        String value = plugin.getConfig().getString("messages." + key);
        return value != null ? value : "<red>Fehlende Nachricht in der Config: " + key;
    }

    /** Nachricht mit Prefix. */
    public Component get(String key, TagResolver... resolvers) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        return MM.deserialize(prefix + raw(key), resolvers);
    }

    /** Nachricht ohne Prefix (z. B. fuer die Actionbar). */
    public Component plain(String key, TagResolver... resolvers) {
        return MM.deserialize(raw(key), resolvers);
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(get(key, resolvers));
    }

    /** Platzhalter, dessen Wert niemals als MiniMessage interpretiert wird. */
    public static TagResolver ph(String name, String value) {
        return Placeholder.unparsed(name, value);
    }

    public static TagResolver ph(String name, long value) {
        return Placeholder.unparsed(name, String.valueOf(value));
    }

    /** Formatiert Sekunden als "9 Min. 59 Sek.". */
    public static String duration(long seconds) {
        long minutes = seconds / 60;
        long rest = seconds % 60;
        if (minutes > 0 && rest > 0) {
            return minutes + " Min. " + rest + " Sek.";
        }
        if (minutes > 0) {
            return minutes + " Min.";
        }
        return rest + " Sek.";
    }
}
