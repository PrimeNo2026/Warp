package de.spawnhome;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;
import java.util.regex.Pattern;

/** Verwaltet und speichert die Homes aller Spieler (homes.yml) sowie den Ein/Aus-Schalter des Home-Systems. */
public final class HomeManager {

    /** Ein gespeichertes Home. */
    public record Home(String name, String world, String dimension,
                       double x, double y, double z, float yaw, float pitch) {

        /** @return die Position oder {@code null}, wenn die Welt nicht geladen ist. */
        public Location toLocation() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }
    }

    public enum SetResult { CREATED, UPDATED, LIMIT_REACHED, NAME_IN_OTHER_DIMENSION }

    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_-]{1,16}");

    private final SpawnHomePlugin plugin;
    private final File file;
    private final Map<UUID, Map<String, Home>> homes = new HashMap<>();
    private boolean enabled = true;

    public HomeManager(SpawnHomePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "homes.yml");
    }

    public static boolean isValidName(String name) {
        return name != null && VALID_NAME.matcher(name).matches();
    }

    public static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        save();
    }

    public Optional<Home> get(UUID owner, String name) {
        Map<String, Home> map = homes.get(owner);
        if (map == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(map.get(key(name)));
    }

    /** Alle Homes eines Spielers, sortiert nach Dimension und Name. */
    public List<Home> list(UUID owner) {
        Map<String, Home> map = homes.get(owner);
        if (map == null) {
            return List.of();
        }
        List<Home> result = new ArrayList<>(map.values());
        result.sort(Comparator.comparing(Home::dimension)
                .thenComparing(h -> h.name().toLowerCase(Locale.ROOT)));
        return result;
    }

    public int count(UUID owner, String dimension) {
        Map<String, Home> map = homes.get(owner);
        if (map == null) {
            return 0;
        }
        int count = 0;
        for (Home h : map.values()) {
            if (h.dimension().equals(dimension)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Legt ein Home an oder verschiebt ein vorhandenes (gleicher Name, gleiche Dimension).
     * Namen sind pro Spieler eindeutig, das Limit gilt pro Dimension.
     */
    public SetResult set(UUID owner, Home home, int maxPerDimension) {
        Map<String, Home> map = homes.computeIfAbsent(owner, k -> new LinkedHashMap<>());
        String key = key(home.name());
        Home existing = map.get(key);
        if (existing != null) {
            if (!existing.dimension().equals(home.dimension())) {
                return SetResult.NAME_IN_OTHER_DIMENSION;
            }
            map.put(key, home);
            save();
            return SetResult.UPDATED;
        }
        if (count(owner, home.dimension()) >= maxPerDimension) {
            if (map.isEmpty()) {
                homes.remove(owner);
            }
            return SetResult.LIMIT_REACHED;
        }
        map.put(key, home);
        save();
        return SetResult.CREATED;
    }

    public boolean delete(UUID owner, String name) {
        Map<String, Home> map = homes.get(owner);
        if (map == null || map.remove(key(name)) == null) {
            return false;
        }
        if (map.isEmpty()) {
            homes.remove(owner);
        }
        save();
        return true;
    }

    public void load() {
        homes.clear();
        enabled = true;
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(file);
        } catch (IOException | InvalidConfigurationException ex) {
            plugin.getLogger().log(Level.SEVERE,
                    "homes.yml konnte nicht gelesen werden. Eine Sicherungskopie wird angelegt.", ex);
            backupBrokenFile();
            return;
        }
        enabled = yaml.getBoolean("home-system-enabled", true);

        ConfigurationSection players = yaml.getConfigurationSection("players");
        if (players == null) {
            return;
        }
        for (String uuidText : players.getKeys(false)) {
            UUID uuid;
            try {
                uuid = UUID.fromString(uuidText);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Ungueltige UUID in homes.yml ignoriert: " + uuidText);
                continue;
            }
            ConfigurationSection playerSection = players.getConfigurationSection(uuidText);
            if (playerSection == null) {
                continue;
            }
            Map<String, Home> map = new LinkedHashMap<>();
            for (String entryKey : playerSection.getKeys(false)) {
                ConfigurationSection s = playerSection.getConfigurationSection(entryKey);
                String world = s == null ? null : s.getString("world");
                if (s == null || world == null) {
                    plugin.getLogger().warning("Defektes Home in homes.yml ignoriert: " + uuidText + "/" + entryKey);
                    continue;
                }
                String name = s.getString("name", entryKey);
                if (!isValidName(name)) {
                    plugin.getLogger().warning("Home mit ungueltigem Namen ignoriert: " + uuidText + "/" + entryKey);
                    continue;
                }
                Home home = new Home(name, world, s.getString("dimension", "NORMAL"),
                        s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                        (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
                map.put(key(name), home);
            }
            if (!map.isEmpty()) {
                homes.put(uuid, map);
            }
        }
    }

    /** Schreibt homes.yml atomar (Temp-Datei + Umbenennen), damit die Datei nie halb geschrieben wird. */
    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("home-system-enabled", enabled);
        for (Map.Entry<UUID, Map<String, Home>> owner : homes.entrySet()) {
            for (Map.Entry<String, Home> entry : owner.getValue().entrySet()) {
                Home h = entry.getValue();
                String path = "players." + owner.getKey() + "." + entry.getKey();
                yaml.set(path + ".name", h.name());
                yaml.set(path + ".world", h.world());
                yaml.set(path + ".dimension", h.dimension());
                yaml.set(path + ".x", h.x());
                yaml.set(path + ".y", h.y());
                yaml.set(path + ".z", h.z());
                yaml.set(path + ".yaw", (double) h.yaw());
                yaml.set(path + ".pitch", (double) h.pitch());
            }
        }
        try {
            File folder = plugin.getDataFolder();
            if (!folder.exists() && !folder.mkdirs()) {
                throw new IOException("Plugin-Ordner konnte nicht erstellt werden");
            }
            Path target = file.toPath();
            Path temp = target.resolveSibling(file.getName() + ".tmp");
            Files.writeString(temp, yaml.saveToString(), StandardCharsets.UTF_8);
            try {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "homes.yml konnte nicht gespeichert werden!", ex);
        }
    }

    private void backupBrokenFile() {
        try {
            Path backup = file.toPath().resolveSibling("homes.yml.broken-" + System.currentTimeMillis());
            Files.copy(file.toPath(), backup, StandardCopyOption.REPLACE_EXISTING);
            plugin.getLogger().severe("Sicherungskopie erstellt: " + backup.getFileName());
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Sicherungskopie konnte nicht erstellt werden.", ex);
        }
    }
}
