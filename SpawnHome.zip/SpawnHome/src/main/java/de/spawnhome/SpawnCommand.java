package de.spawnhome;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** /spawn - Teleport zum Spawn (Koordinaten in der config.yml). */
public final class SpawnCommand implements CommandExecutor {

    private final Messages messages;
    private final TeleportManager teleports;

    public SpawnCommand(Messages messages, TeleportManager teleports) {
        this.messages = messages;
        this.teleports = teleports;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            messages.send(sender, "players-only");
            return true;
        }
        if (!player.hasPermission("spawnhome.spawn")) {
            messages.send(player, "no-permission");
            return true;
        }
        teleports.start(player, TeleportManager.Kind.SPAWN, null, "");
        return true;
    }
}
