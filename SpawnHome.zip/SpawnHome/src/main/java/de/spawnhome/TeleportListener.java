package de.spawnhome;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.UUID;

/** Erkennt alles, was einen laufenden Teleport-Countdown abbricht, und markiert Spieler-Kaempfe. */
public final class TeleportListener implements Listener {

    private final TeleportManager teleports;
    private final LocateManager locates;

    public TeleportListener(TeleportManager teleports, LocateManager locates) {
        this.teleports = teleports;
        this.locates = locates;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!teleports.hasSessions() || !event.hasChangedPosition()) {
            return;
        }
        teleports.checkMove(event.getPlayer(), event.getTo());
    }

    /** Jeder erlittene Schaden bricht ab. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            teleports.cancel(player.getUniqueId(), "cancel-damage");
        }
    }

    /** Spieler gegen Spieler: Kampf markieren (Sperre) und den Angreifer-Countdown abbrechen. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerFight(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        Player attacker = resolveAttacker(event.getDamager());
        if (attacker == null || attacker.getUniqueId().equals(victim.getUniqueId())) {
            return;
        }
        teleports.markCombat(attacker.getUniqueId(), victim.getUniqueId());
        teleports.cancel(attacker.getUniqueId(), "cancel-combat");
    }

    /** Auch ein Versuch zaehlt (ignoreCancelled bewusst aus). */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockPlace(BlockPlaceEvent event) {
        teleports.cancel(event.getPlayer().getUniqueId(), "cancel-block");
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreak(BlockBreakEvent event) {
        teleports.cancel(event.getPlayer().getUniqueId(), "cancel-block");
    }

    /** Fremd ausgeloeste Teleports (Perle, Portal, Plugins) brechen ab; der eigene Teleport laeuft erst danach. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        teleports.cancel(event.getPlayer().getUniqueId(), "cancel-teleport");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        teleports.remove(id);
        locates.stop(id, null);
    }

    private static Player resolveAttacker(Entity damager) {
        if (damager instanceof Player player) {
            return player;
        }
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player shooter) {
            return shooter;
        }
        return null;
    }
}
