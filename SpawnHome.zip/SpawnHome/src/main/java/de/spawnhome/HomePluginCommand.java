package de.spawnhome;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static de.spawnhome.Messages.ph;

/** /homeplugin on|off|reload - schaltet das Home-System ein/aus (betrifft nicht /spawn). */
public final class HomePluginCommand implements CommandExecutor, TabCompleter {

    private static final List<String> OPTIONS = List.of("on", "off", "reload");

    private final Settings settings;
    private final Messages messages;
    private final HomeManager homes;
    private final TeleportManager teleports;
    private final LocateManager locates;

    public HomePluginCommand(Settings settings, Messages messages, HomeManager homes,
                             TeleportManager teleports, LocateManager locates) {
        this.settings = settings;
        this.messages = messages;
        this.homes = homes;
        this.teleports = teleports;
        this.locates = locates;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("spawnhome.admin")) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length != 1) {
            messages.send(sender, "usage", ph("usage", "/homeplugin <on|off|reload>"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on" -> {
                homes.setEnabled(true);
                messages.send(sender, "homeplugin-on");
            }
            case "off" -> {
                homes.setEnabled(false);
                teleports.cancelHomeSessions();
                locates.stopAll("home-disabled");
                messages.send(sender, "homeplugin-off");
            }
            case "reload" -> {
                settings.reload();
                messages.send(sender, "reload-done");
            }
            default -> messages.send(sender, "usage", ph("usage", "/homeplugin <on|off|reload>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("spawnhome.admin") || args.length != 1) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String option : OPTIONS) {
            if (option.startsWith(prefix)) {
                result.add(option);
            }
        }
        return result;
    }
}
