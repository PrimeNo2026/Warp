package de.spawnhome;

import de.spawnhome.HomeManager.Home;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static de.spawnhome.Messages.ph;

/** /home, /sethome, /delhome, /homes und /locatehome. */
public final class HomeCommands implements CommandExecutor, TabCompleter {

    private final Settings settings;
    private final Messages messages;
    private final HomeManager homes;
    private final TeleportManager teleports;
    private final LocateManager locates;

    public HomeCommands(Settings settings, Messages messages, HomeManager homes,
                        TeleportManager teleports, LocateManager locates) {
        this.settings = settings;
        this.messages = messages;
        this.homes = homes;
        this.teleports = teleports;
        this.locates = locates;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            messages.send(sender, "players-only");
            return true;
        }
        if (!player.hasPermission("spawnhome.home")) {
            messages.send(player, "no-permission");
            return true;
        }
        if (!homes.isEnabled()) {
            messages.send(player, "home-disabled");
            return true;
        }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "sethome" -> setHome(player, args);
            case "home" -> goHome(player, args);
            case "delhome" -> deleteHome(player, args);
            case "homes" -> listHomes(player);
            case "locatehome" -> locateHome(player, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private void setHome(Player player, String[] args) {
        if (args.length > 1) {
            usage(player, "/sethome [Name]");
            return;
        }
        String name = args.length == 1 ? args[0] : settings.defaultHomeName();
        if (!HomeManager.isValidName(name)) {
            messages.send(player, "home-invalid-name");
            return;
        }
        UUID id = player.getUniqueId();
        Location location = player.getLocation();
        World world = location.getWorld();
        String dimension = world.getEnvironment().name();
        Home home = new Home(name, world.getName(), dimension,
                location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        int max = settings.maxHomesPerDimension();
        String dimensionName = settings.dimensionName(dimension);

        switch (homes.set(id, home, max)) {
            case CREATED -> messages.send(player, "home-set",
                    ph("name", name), ph("dimension", dimensionName),
                    ph("count", homes.count(id, dimension)), ph("max", max));
            case UPDATED -> messages.send(player, "home-updated", ph("name", name));
            case LIMIT_REACHED -> messages.send(player, "home-limit",
                    ph("dimension", dimensionName), ph("max", max));
            case NAME_IN_OTHER_DIMENSION -> messages.send(player, "home-name-other-dimension", ph("name", name));
        }
    }

    private void goHome(Player player, String[] args) {
        if (args.length > 1) {
            usage(player, "/home [Name]");
            return;
        }
        Optional<Home> home = pick(player, args);
        home.ifPresent(h -> teleports.start(player, TeleportManager.Kind.HOME, HomeManager.key(h.name()), h.name()));
    }

    private void deleteHome(Player player, String[] args) {
        if (args.length != 1) {
            usage(player, "/delhome [Name]");
            return;
        }
        UUID id = player.getUniqueId();
        Optional<Home> home = homes.get(id, args[0]);
        if (home.isEmpty()) {
            messages.send(player, "home-not-found", ph("name", args[0]));
            return;
        }
        homes.delete(id, args[0]);
        messages.send(player, "home-deleted", ph("name", home.get().name()));
    }

    private void listHomes(Player player) {
        List<Home> all = homes.list(player.getUniqueId());
        if (all.isEmpty()) {
            messages.send(player, "homes-empty");
            return;
        }
        messages.send(player, "homes-header");

        Map<String, List<Home>> byDimension = new LinkedHashMap<>();
        byDimension.put("NORMAL", new ArrayList<>());
        byDimension.put("NETHER", new ArrayList<>());
        byDimension.put("THE_END", new ArrayList<>());
        for (Home home : all) {
            byDimension.computeIfAbsent(home.dimension(), k -> new ArrayList<>()).add(home);
        }

        for (Map.Entry<String, List<Home>> group : byDimension.entrySet()) {
            if (group.getValue().isEmpty()) {
                continue;
            }
            Component line = Component.text(
                    " " + settings.dimensionName(group.getKey())
                            + " (" + group.getValue().size() + "/" + settings.maxHomesPerDimension() + "): ",
                    NamedTextColor.GRAY);
            boolean first = true;
            for (Home home : group.getValue()) {
                if (!first) {
                    line = line.append(Component.text(", ", NamedTextColor.DARK_GRAY));
                }
                first = false;
                String hover = String.format(Locale.ROOT, "%s: %.0f, %.0f, %.0f",
                        home.world(), home.x(), home.y(), home.z());
                line = line.append(Component.text(home.name(), NamedTextColor.AQUA)
                        .clickEvent(ClickEvent.runCommand("/home " + home.name()))
                        .hoverEvent(HoverEvent.showText(Component.text(hover, NamedTextColor.GRAY))));
            }
            player.sendMessage(line);
        }
    }

    private void locateHome(Player player, String[] args) {
        if (args.length > 1) {
            usage(player, "/locatehome [Name]");
            return;
        }
        Optional<Home> picked = pick(player, args);
        if (picked.isEmpty()) {
            return;
        }
        Home home = picked.get();
        Location target = home.toLocation();
        if (target == null) {
            messages.send(player, "home-world-missing", ph("name", home.name()));
            return;
        }
        if (!target.getWorld().equals(player.getWorld())) {
            messages.send(player, "locate-wrong-dimension",
                    ph("name", home.name()), ph("dimension", settings.dimensionName(home.dimension())));
            return;
        }
        locates.start(player, home);
    }

    /**
     * Ermittelt das gemeinte Home. Ohne Namen: das Standard-Home, sonst das einzige vorhandene Home.
     * Sendet selbst die passende Fehlermeldung, falls keines eindeutig ist.
     */
    private Optional<Home> pick(Player player, String[] args) {
        UUID id = player.getUniqueId();
        if (args.length == 1) {
            Optional<Home> home = homes.get(id, args[0]);
            if (home.isEmpty()) {
                messages.send(player, "home-not-found", ph("name", args[0]));
            }
            return home;
        }
        List<Home> all = homes.list(id);
        if (all.isEmpty()) {
            messages.send(player, "homes-empty");
            return Optional.empty();
        }
        Optional<Home> standard = homes.get(id, settings.defaultHomeName());
        if (standard.isPresent()) {
            return standard;
        }
        if (all.size() == 1) {
            return Optional.of(all.get(0));
        }
        messages.send(player, "home-choose");
        listHomes(player);
        return Optional.empty();
    }

    private void usage(Player player, String usage) {
        messages.send(player, "usage", ph("usage", usage));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player player) || args.length != 1) {
            return List.of();
        }
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("sethome") || name.equals("homes")) {
            return List.of();
        }
        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (Home home : homes.list(player.getUniqueId())) {
            if (home.name().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                result.add(home.name());
            }
        }
        return result;
    }
}
